transparent = true;
$(document).scroll(function() {
    if( $(this).scrollTop() > 360 ) {
        if(transparent) {
            transparent = false;
            $('nav[role="navigation"]').removeClass('navbar-transparent');
		    $('nav[role="navigation"]').addClass('navbar-custom');
        }
    } 
	else {
        if( !transparent ) {
            transparent = true;
            $('nav[role="navigation"]').addClass('navbar-transparent');
			$('nav[role="navigation"]').removeClass('navbar-custom');
        }
    }
});



























