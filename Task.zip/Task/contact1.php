<!DOCTYPE html>
<html>
   <head>
      <title>CONTACTS</title>
	  <link href="styles/bootstrap.min.css" rel="stylesheet">
      <link href="styles/bootstrap.css" rel="stylesheet">
	  <link href="styles/bootstrapValidator.css" rel="stylesheet">
	  <link href="styles/main.css" rel="stylesheet">
   </head>
   <body>
             <!-- -------------------------------------------navigation bar---------------------------------------------- -->
		     <nav class="navbar navbar-fixed-top" role="navigation" style="background-color: #74AFAD;">
			      <div class="navbar-header">
				      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#data-navigate">
					       <span><img src="images/hambars.png" height="50px" width="50px"></span>
					  </button>
				      <a class="navbar-brand" href="index.html">NXTLIFE<br/>TECHNOLOGIES</a>
				  </div>
				  <div class="collapse navbar-collapse" id="data-navigate">
				      <ul class="nav navbar-nav">
					      <li><a href="index.html">HOME</a></li>
					      <li class="active"><a href="contact1.php">CONTACTS</a></li>
						  <li><a href="about.html">ABOUT</a></li>
					  </ul>
				  </div>
			 </nav>
			 
			 <!-- -------------------------------------------banner---------------------------------------------- -->
			 <div>
		        <img class="banner banner-contact" src="images/contact.jpg">
		     </div>
			 
			 <!-- -------------------------------------------contact table---------------------------------------------- -->
			 <div class="container table_list">
               <div class="row">
			        <h2 class="align">CONTACT LIST</h2><hr class="horizontal"/>
                   <div class="col-md-12"> 			 
						<?php	 
						   $user='root';
						   $pass='';
						   $db='contacts';
						
						   $db=new mysqli('localhost',$user,$pass,$db) or die("Error Connecting");
						   /* echo "<br/>Correctly Connected"; */
						   
						   ?>
						 
							
						   <table class="table table-striped">
							   <thead>
								   <tr>
									  <th>S No.</th>
									  <th>Name</th>
									  <th>Email</th>
									  <th>Contact</th>
									  <th>Gender</th>
									  <th>Comments</th>
								   </tr>
							   </thead>
							   <tbody>
							   
									<?php
									  if($_POST['name']!=""){
										   $name= $_POST['name'];
										   $email= $_POST['email'];
										   $num= $_POST['number'];
										   $gender= $_POST['gender'];
										   $msg=$_POST['msg'];
										   
										   $query1="INSERT INTO contact_table (name,email,contact,gender,message) VALUES ('$name','$email','$num','$gender','$msg')";
										   $result1=mysqli_query($db,$query1);
										   show_data($db);
									   }	    	
										
									   
									   else if($_POST['email_del']!=""){
										   $email_del=$_POST['email_del'];
										   
										   $query2="DELETE FROM contact_table WHERE email='$email_del'";
										   $result2=mysqli_query($db,$query2);
									       show_data($db);
									   }
									   
									   else{
									       show_data($db);
									   	 } 
										 
									   function show_data($db){
											 $query3="SELECT * FROM contact_table";
						                     $result3=mysqli_query($db,$query3);
										   
										     while($row=mysqli_fetch_array($result3)){
										       echo "<br/><tr><th>".$row['s_no']."</th><th>".$row['name'].
												    "</th><th>".$row['email']."</th><th>".$row['contact'].
												    "</th><th>".$row['gender']."</th><th>".$row['message'];
											  }
										 }
								    ?>
							   </tbody>
						  </table> 
				    </div>
				</div>		
					
					
					<!-- -------------------------------------------Contact table Edition & Deletion----------------------------------------- -->
						  <div class="row">
								   <div class="col-md-4">
										<div class="form-group"> 
										  <a class="btn btn-success btn-lg" type="button" href="index.html">Edit Contact</a>
										</div>
								   </div>
								   <form role="form" class="form-inline" data-toggle="validator" method="POST" action="contact1.php">
										   <div class="col-md-3">	
												<div class="form-group"> 
												  <label for="email_del" class="sr-only">Email:</label>
												  <input type="email" id="email_del" name="email_del" class="form-control" placeholder="abc@xy.com" required/>
												  <div class="help-block with-errors"></div>
												</div> 
										   </div>
										   <div class="col-md-5">
											<button class="btn btn-danger btn-lg" type="submit">Delete Contact</button>
										   </div>	 
								   </form>
						  </div>
				</div>
				
			 <!-- -------------------------------------------footer---------------------------------------------- -->	
			 <div class="row footer" style="margin-top:100px;">
				<div class="col-md-6 col-xs-6 col-md-offset-5 col-xs-offset-4">
					<strong>&copy; NxtLife Technologies</strong>
				</div>
			 </div>
	  
	  <script src="scripts/jquery-1.5.2.min.js"></script>
	  <script src="scripts/jquery.min.js"></script>
      <script src="scripts/bootstrap.min.js"></script>	
	  <script src="scripts/main.js"></script>
	  <script src="scripts/bootstrapValidator.js"></script>
   </body>
</html>		 